using Backload.Contracts.Context;
using Backload.Contracts.FileHandler;
using Backload.Demo.Models;
using Backload.Helper;
using System.Diagnostics;
using System.Net;
using System.Threading.Tasks;
using System.Web;
using System.Web.Mvc;


namespace Backload.Demo.Controllers
{

    /// <summary>
    /// A custom database controller used in the database storage demo
    /// </summary>
    /// <remarks>
    /// IMPORTANT NOTE:
    /// Because we use the same configuration file for all demos, this database demo implements a workaround for the missing
    /// filesUrlPattern="{Backload}" setting in the configuration file. In your project configure filesUrlPattern="{Backload}"
    /// </remarks>
    public class CustomDatabaseController : Controller
    {
        /// <summary>
        /// Custom database handler. 
        /// To access it in an Javascript ajax request use: <code>var url = "/CustomDatabase/DataHandler";</code>.
        /// </summary>
        [AcceptVerbs(HttpVerbs.Get | HttpVerbs.Post | HttpVerbs.Put | HttpVerbs.Delete | HttpVerbs.Options)]
        public async Task<ActionResult> DataHandler()
        {

            try
            {

                using (var context = new FilesContext())
                {

                    // Create and initialize the handler
                    IFileHandler handler = Backload.FileHandler.Create();
                    handler.Init(HttpContext.Request, context);


                    // Call the execution pipeline and get the result
                    IBackloadResult result = await handler.Execute();


                    // Save changes to database
                    await context.SaveChangesAsync();

                    
                    // Helper to create an ActionResult object from the IBackloadResult instance
                    return ResultCreator.Create(result);
                }

            }
            catch
            {
                return new HttpStatusCodeResult(HttpStatusCode.InternalServerError);
            }

        }
    }
}
