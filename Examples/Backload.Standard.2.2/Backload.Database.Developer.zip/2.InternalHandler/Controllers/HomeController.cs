using System.Web.Mvc;

namespace Backload.Demo.Controllers
{
    public class HomeController : Controller
    {

        // Start view
        public ActionResult Index()
        {
            return View();
        }

    }
}
