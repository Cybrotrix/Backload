﻿/*jslint unparam: true */
/*global window, $ */
$(function () {
    'use strict';

    // Name of a web application (usually in full IIS mode). Can be found in Properties/Web/Server/Project-Url. Example: http://localhost/Demo (Name of web application is "Demo")
    var web_app = '/';

    // We use the upload handler integrated into Backload:
    // In this example we set an objectContect (id) in the URL query (or as form parameter). The value of the opjectContext parameter  
    // will be added to the path as a sub-folder of the storage root folder (storageRoot\objectContext\file). You can assign a user id
    // to objectContext as user directory. Instead of setting the objectContext client side you can also be set server side, 
    // e.g. server side events (see also Custom Data Provider Demo, 2.2+).
    var url = web_app + 'Backload/FileHandler?objectContext=C5F260DD3787';


    $('#fileupload').fileupload({
        url: url,
        dataType: 'json',
        autoUpload: false,
        disableImageResize: /Android(?!.*Chrome)|Opera/
            .test(window.navigator && navigator.userAgent),
        previewCrop: true
    })

        // When the following init method call causes problems bind event handlers manually 
        // like in blueimp's basic plus example (https://blueimp.github.io/jQuery-File-Upload/basic-plus.html)
    .data('blueimp-fileupload').initTheme("BasicPlus");
});
