What plugin to choose?

Unlike filesystem storage, Database and Azure Blob storage need a plugin in the "~/Backload/Plugin" folder. 
NuGet manager has currently no reliable mechanism to store assets (supporting files) for ASP.NET Core projects.
So you need to copy the plugins manually into the plugin folder (or start with the developer package). You 
can start with the demo package or copy the plugin from this folder.

There are 2 things to mention:
  1. Release version of the main package (Backload.AspNetCore) and the plugin version must match because this 
     guaranties that the interfaces are equal (e.g. 2.2.8). Loading a plugin with a different release version 
     probably results in an assembly loader exception. Prerelease identifiers like  -pre  or  -rc1  must not 
     be the same.
  2. Choose the appropriate .NET version (TFM) of the plugin for your project. If your project runs on native 
     ASP.NET Core (cross-plattform) copy the  netstandard1.5  plugin into the plugin folder. Otherwise, if 
     your project runs on ASP.NET Core over the full framework copy the  net461  plugin. The other available 
     plugins are for the traditional framework (net40, net45).


More:
https://github.com/blackcity/Backload/wiki#general
